package com.zensar.olx.bean;

public enum Active {

	TRUE, FALSE;
}
