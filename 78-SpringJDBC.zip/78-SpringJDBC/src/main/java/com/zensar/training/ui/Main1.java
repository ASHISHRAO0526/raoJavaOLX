package com.zensar.training.ui;

public class Main1 {
	public static void main(String[] args) {
		while(true) {
			MenuHandler handler=new MenuHandler();
			handler.displayMenu();
		}
	}
}
